''' Hello1 '''
import something
''' Hello2 '''
class ClassA():
    def __init__(self):
        pass
    def methodA(self, parm1=""):
        pass
class ClassB(ClassA):
    def methodB(self):
        pass
def Func():
        pass
    ''' Hello3 '''